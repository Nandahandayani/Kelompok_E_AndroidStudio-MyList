# KelompokE_AndroidStudio-MyList
Tugas Aplikasi UTS To-Do List Minimalist dengan nama Aplikasi "MyList" , Karya dari Kelompok E

Anggota Kelompok :
- Arief Kurniawan
- Nanda Handayani
- Siti Aisah Jamil
- Rani Rohaeni
