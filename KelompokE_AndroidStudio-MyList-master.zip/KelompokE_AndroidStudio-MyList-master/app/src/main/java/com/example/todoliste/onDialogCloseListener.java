package com.example.todoliste;

import android.content.DialogInterface;

public interface onDialogCloseListener {
    void onDialogClose(DialogInterface dialogInterface);
}
